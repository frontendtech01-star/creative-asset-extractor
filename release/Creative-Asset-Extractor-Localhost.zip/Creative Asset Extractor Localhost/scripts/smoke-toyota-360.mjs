import fs from 'node:fs/promises';
import WebSocket from 'ws';

const baseUrl = process.env.SMOKE_BASE_URL || 'http://127.0.0.1:3000';
const targetUrl = process.env.SMOKE_TOYOTA_URL || 'https://www.toyota.com/espanol/tacoma/';
const timeoutMs = Number(process.env.SMOKE_TIMEOUT_MS || 180_000);

const response = await fetch(`${baseUrl}/api/extract`, {
  method: 'POST',
  headers: { 'content-type': 'application/json' },
  body: JSON.stringify({
    url: targetUrl,
    extractionMode: 'full',
    crawlMode: 'fast',
  }),
});

if (!response.ok) {
  throw new Error(`Toyota extraction request failed: ${response.status} ${await response.text()}`);
}

const initial = await response.json();
if (!initial?.extractId) {
  throw new Error(`Toyota extraction did not return an extractId: ${JSON.stringify(initial)}`);
}

const wsUrl = `${baseUrl.replace(/^http/, 'ws')}/ws/extract?extractId=${encodeURIComponent(initial.extractId)}`;
let lastCounters = { images: 0, videos: 0, fonts: 0, colors: 0 };
const result = await new Promise((resolve, reject) => {
  const ws = new WebSocket(wsUrl);
  const timeout = setTimeout(() => {
    ws.close();
    reject(new Error(`Toyota extraction timed out after ${timeoutMs}ms`));
  }, timeoutMs);

  ws.on('message', (raw) => {
    const event = JSON.parse(String(raw));
    if (event.type === 'counters') {
      const counters = event.counters || {};
      lastCounters = {
        images: Number(counters.images || 0),
        videos: Number(counters.videos || 0),
        fonts: Number(counters.fonts || 0),
        colors: Number(counters.colors || 0),
      };
      process.stdout.write(
        `Progress: images=${counters.images || 0} fonts=${counters.fonts || 0} videos=${counters.videos || 0}\n`,
      );
    }
    if (event.type === 'complete') {
      clearTimeout(timeout);
      ws.close();
      resolve(event.result || {});
    }
    if (event.type === 'error') {
      clearTimeout(timeout);
      ws.close();
      reject(new Error(event.message || 'Toyota extraction failed'));
    }
  });
  ws.on('error', (error) => {
    clearTimeout(timeout);
    reject(error);
  });
});

const images = Array.isArray(result.images) ? result.images : [];
const exactCounters = {
  images: images.length,
  videos: Array.isArray(result.videos) ? result.videos.length : 0,
  fonts: Array.isArray(result.fonts) ? result.fonts.length : 0,
  colors: Array.isArray(result.colors) ? result.colors.length : 0,
};
if (JSON.stringify(lastCounters) !== JSON.stringify(exactCounters)) {
  throw new Error(`Toyota smoke failed: final progress counters ${JSON.stringify(lastCounters)} do not match finalized assets ${JSON.stringify(exactCounters)}.`);
}
console.log(`OK: finalized counters match the exact result ${JSON.stringify(exactCounters)}.`);
const sequenceImages = images.filter((image) =>
  Boolean(image?.is360Sequence || image?.sequenceKey || /\/36\/\d+\.(?:png|jpe?g|webp)(?:[?#]|$)/i.test(String(image?.url || ''))),
);
const groups = new Map();
for (const image of sequenceImages) {
  const key = String(image?.sequenceKey || image?.sequenceLabel || 'unknown');
  if (!groups.has(key)) groups.set(key, []);
  groups.get(key).push(image);
}

const groupSummary = [...groups.entries()].map(([key, group]) => ({
  key,
  count: group.length,
  frames: group
    .map((image) => Number(image?.sequenceFrame || image?.frameNumber || String(image?.url || '').match(/\/(\d+)\.(?:png|jpe?g|webp)(?:[?#]|$)/i)?.[1]))
    .filter(Number.isFinite)
    .sort((a, b) => a - b),
}));

await fs.writeFile('/tmp/toyota-full-result.json', JSON.stringify(result, null, 2));
console.log(JSON.stringify({
  images: images.length,
  fonts: Array.isArray(result.fonts) ? result.fonts.length : 0,
  videos: Array.isArray(result.videos) ? result.videos.length : 0,
  colors: Array.isArray(result.colors) ? result.colors.length : 0,
  sequenceImages: sequenceImages.length,
  groups: groupSummary,
}, null, 2));

const completeGroup = groupSummary.find((group) =>
  group.count === 36 && group.frames.length === 36 && group.frames.every((frame, index) => frame === index + 1),
);
if (!completeGroup) {
  throw new Error('Toyota smoke failed: no complete ordered 36-frame 360 sequence was extracted.');
}

const completeFrames = groups.get(completeGroup.key);
await Promise.all(completeFrames.map(async (image) => {
  const check = await fetch(image.url, { headers: { referer: targetUrl } });
  if (!check.ok) throw new Error(`Toyota frame request failed (${check.status}): ${image.url}`);
  const contentType = String(check.headers.get('content-type') || '');
  if (!contentType.startsWith('image/')) {
    throw new Error(`Toyota frame is not image data (${contentType || 'unknown'}): ${image.url}`);
  }
  const bytes = new Uint8Array(await check.arrayBuffer());
  if (bytes.length < 1024) throw new Error(`Toyota frame is unexpectedly small (${bytes.length} bytes): ${image.url}`);
}));

console.log(`OK: Toyota extracted ordered frames 01-36 for ${completeGroup.key}; all 36 frame downloads are valid images.`);
