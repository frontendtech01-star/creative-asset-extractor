import fs from 'node:fs/promises';
import path from 'node:path';

const resultPath = process.env.SMOKE_RESULT_FILE || '/tmp/toyota-full-result.json';
const outputRoot = process.env.SMOKE_OUTPUT_DIR || path.join(
  process.env.HOME || '',
  'Downloads',
  'CreativeAssetExtractor-SmokeTest',
  'Toyota-Tacoma',
);
const result = JSON.parse(await fs.readFile(resultPath, 'utf8'));
const images = Array.isArray(result.images) ? result.images : [];
const videos = Array.isArray(result.videos) ? result.videos : [];
const fonts = Array.isArray(result.fonts) ? result.fonts : [];
const sequenceByFrame = new Map();
for (const image of images.filter((item) => String(item?.source || '').includes('360-sequence'))) {
  const frame = Number(image?.sequenceFrame || 0);
  if (frame >= 1 && frame <= 36 && !sequenceByFrame.has(frame)) sequenceByFrame.set(frame, image);
}
const sequence = [...sequenceByFrame.values()]
  .sort((a, b) => Number(a.sequenceFrame || 0) - Number(b.sequenceFrame || 0));

if (sequence.length !== 36) {
  throw new Error(`Expected 36 Toyota frames, found ${sequence.length}`);
}

const sequenceDir = path.join(outputRoot, 'Images', '360_Sequence');
await fs.mkdir(sequenceDir, { recursive: true });

await Promise.all(sequence.map(async (image) => {
  const frame = Number(image.sequenceFrame || 0);
  const response = await fetch(image.url, {
    headers: { referer: 'https://www.toyota.com/espanol/tacoma/' },
  });
  if (!response.ok) throw new Error(`Frame ${frame} returned HTTP ${response.status}`);
  const contentType = String(response.headers.get('content-type') || '');
  if (!contentType.startsWith('image/')) throw new Error(`Frame ${frame} is not image data`);
  const bytes = new Uint8Array(await response.arrayBuffer());
  if (bytes.length < 1024) throw new Error(`Frame ${frame} is unexpectedly small`);
  await fs.writeFile(path.join(sequenceDir, `frame_${String(frame).padStart(3, '0')}.png`), bytes);
}));

const regularImages = images.filter((image) => !String(image?.source || '').includes('360-sequence'));
await fs.writeFile(path.join(outputRoot, 'image-urls.txt'), `${regularImages.map((image) => image.url).filter(Boolean).join('\n')}\n`);
await fs.writeFile(path.join(outputRoot, 'video-urls.txt'), `${videos.map((video) => video.url || video.sourceUrl).filter(Boolean).join('\n')}\n`);
await fs.writeFile(path.join(outputRoot, 'font-urls.txt'), `${fonts.map((font) => font.url).filter(Boolean).join('\n')}\n`);
await fs.writeFile(path.join(outputRoot, 'extraction-result.json'), JSON.stringify(result, null, 2));
await fs.writeFile(path.join(outputRoot, 'SMOKE-RESULT.txt'), [
  'Toyota Tacoma extraction smoke test',
  'Source: https://www.toyota.com/espanol/tacoma/',
  `Images: ${images.length}`,
  `Regular images: ${regularImages.length}`,
  `360 frames: ${sequence.length} (01-36)`,
  `Videos: ${videos.length}`,
  `Fonts: ${fonts.length}`,
  `Colors: ${Array.isArray(result.colors) ? result.colors.length : 0}`,
  'All 36 frame files were downloaded and validated as image data.',
  '',
].join('\n'));

console.log(outputRoot);
