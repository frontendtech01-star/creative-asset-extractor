import React, { useState, useEffect } from 'react';
import { Check, Copy, Download, Video as VideoIcon, Search, Globe } from 'lucide-react';
import { getDesktopBridge } from '../lib/desktopBridge';
import {
  canonicalBrightcovePlayerUrlFromItem,
  isDirectVideoAssetUrl,
  isPlatformHostedUrl,
  isTransportStreamSegmentUrl,
  isUsableExtractedVideo,
  isWistiaHelperResourceUrl,
} from '../lib/visibleVideos';

const isTechnicalPlayerResourceUrl = (rawUrl: string) => {
  const value = String(rawUrl || '').trim().toLowerCase();
  if (!value) return true;
  if (isTransportStreamSegmentUrl(value)) return true;
  if (/\.(?:js|mjs|css|json|map|xml|txt|ico)(?:[?#@]|$)/i.test(value)) return true;
  if (isWistiaHelperResourceUrl(value)) return true;
  try {
    const parsed = new URL(value);
    const host = parsed.hostname.replace(/^www\./, '').toLowerCase();
    const path = parsed.pathname.toLowerCase();
    return (host === 'youtube.com' || host.endsWith('.youtube.com')) && (
      path === '/iframe_api' ||
      path.includes('/www-widgetapi') ||
      path.startsWith('/s/player/') ||
      path.startsWith('/youtubei/') ||
      path.startsWith('/api/')
    );
  } catch {
    return false;
  }
};

const isTechnicalVideoItem = (video: any) => {
  const title = String(video?.title || video?.name || video?.label || '').trim();
  const hasCanonicalBrightcove = Boolean(canonicalBrightcovePlayerUrlFromItem(video));
  if (!hasCanonicalBrightcove && /^(?:tracker(?:\s*\d+)?|(?:master|rendition)\.m3u8(?:\s*\d+)?|(?:segment|seg|fragment|chunk)[^/\s]*\.ts(?:\s*\d+)?)$/i.test(title)) {
    return true;
  }
  const candidates = [
    video?.url,
    video?.embedUrl,
    video?.sourceStreamUrl,
    video?.downloadUrl,
    video?.originalUrl,
    video?.sourceUrl,
    video?.pageUrl,
  ];
  return candidates.some((candidate) => typeof candidate === 'string' && isTechnicalPlayerResourceUrl(candidate));
};

const normalizeExtractedVideoCard = (video: any, seedUrl: string) => {
  const brightcoveCanonical = canonicalBrightcovePlayerUrlFromItem(video, seedUrl);
  if (!brightcoveCanonical) return video;
  const title = String(video?.title || video?.name || '').trim();
  return {
    ...video,
    url: brightcoveCanonical,
    embedUrl: brightcoveCanonical,
    provider: 'brightcove',
    type: 'brightcove',
    title: /^tracker(?:\s*\d+)?$/i.test(title) ? 'Brightcove video' : title || 'Brightcove video',
  };
};

const dedupeVisibleVideoCards = (items: any[], seedUrl: string) => {
  const seen = new Set<string>();
  return items.filter((item) => {
    const brightcoveCanonical = canonicalBrightcovePlayerUrlFromItem(item, seedUrl);
    const key = brightcoveCanonical || String(item?.url || item?.embedUrl || '').trim();
    if (!key) return false;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
};

const resolvePlatformVideoUrl = (video: any) => {
  const brightcoveCanonical = canonicalBrightcovePlayerUrlFromItem(video);
  if (brightcoveCanonical) return brightcoveCanonical;
  const candidates = [
    video?.embedUrl,
    video?.url,
    video?.sourceStreamUrl,
    video?.originalUrl,
    video?.sourceUrl,
    video?.pageUrl,
  ];
  const platformUrl = candidates.find(
    (candidate) => typeof candidate === 'string' && !isTechnicalPlayerResourceUrl(candidate) && isPlatformHostedUrl(candidate)
  );
  if (platformUrl) return String(platformUrl);
  if (video?.vimeoId) return `https://vimeo.com/${video.vimeoId}`;
  if (video?.wistiaHashedId) return `https://fast.wistia.net/embed/iframe/${video.wistiaHashedId}`;
  return '';
};

const resolveVideoDownloadRequest = (video: any, seedUrl: string) => {
  const directCandidates = [
    video?.sourceStreamUrl,
    video?.downloadUrl,
    video?.originalUrl,
    video?.url,
  ];
  const directUrl = directCandidates.find(
    (candidate) => typeof candidate === 'string' && !isTechnicalPlayerResourceUrl(candidate) && isDirectVideoAssetUrl(candidate)
  );
  if (directUrl) {
    const isManifest = /\.(?:m3u8|mpd)(?:\?|$)/i.test(String(directUrl));
    return {
      endpoint: isManifest ? '/api/platform-video-download' : '/api/direct-video-download',
      url: String(directUrl),
      sourcePageUrl: String(video?.sourceUrl || video?.pageUrl || seedUrl || directUrl),
    };
  }

  const platformUrl = resolvePlatformVideoUrl(video) || (isPlatformHostedUrl(seedUrl) ? seedUrl : '');
  if (platformUrl) {
    return {
      endpoint: '/api/platform-video-download',
      url: String(platformUrl),
      sourcePageUrl: String(video?.sourceUrl || video?.pageUrl || seedUrl || platformUrl),
    };
  }

  return {
    endpoint: '/api/direct-video-download',
    url: String(video?.url || ''),
    sourcePageUrl: String(video?.sourceUrl || video?.pageUrl || seedUrl || video?.url || ''),
  };
};

const resolveEmbeddedVideoLink = (video: any) => {
  return resolvePlatformVideoUrl(video) || String([video?.embedUrl, video?.url, video?.sourceUrl, video?.pageUrl].find((candidate) => typeof candidate === 'string' && /^https?:\/\//i.test(candidate) && !isTechnicalPlayerResourceUrl(candidate)) || '');
};

const isEmbeddedVideo = (video: any) => {
  const url = String(video?.url || '');
  if (video?.isDirect || video?.isVimeoDirect || video?.isWistiaDirect || video?.isYouTubeDirect) return false;
  return !isDirectVideoAssetUrl(url);
};

const resolveEmbedPreviewUrl = (video: any) => {
  const source = resolveEmbeddedVideoLink(video);
  if (!source) return '';
  try {
    const parsed = new URL(source);
    const host = parsed.hostname.replace(/^www\./, '').toLowerCase();
    if (host === 'vimeo.com' || host.endsWith('.vimeo.com')) {
      const id = video?.vimeoId || parsed.pathname.match(/\/(?:video\/)?(\d+)/)?.[1];
      return id ? `https://player.vimeo.com/video/${id}` : '';
    }
    if (host === 'youtu.be' || host === 'youtube.com' || host.endsWith('.youtube.com')) {
      const id =
        parsed.searchParams.get('v') ||
        parsed.pathname.match(/\/(?:embed|shorts|live)\/([^/?#]+)/)?.[1] ||
        (host === 'youtu.be' ? parsed.pathname.split('/').filter(Boolean)[0] : '');
      return id ? `https://www.youtube.com/embed/${id}` : '';
    }
    if (host.includes('wistia.com') || host.includes('wistia.net')) {
      const id = video?.wistiaHashedId || parsed.pathname.match(/\/(?:embed\/medias|medias|embed\/iframe)\/([a-z0-9]{8,12})/i)?.[1];
      return id ? `https://fast.wistia.net/embed/iframe/${id}` : '';
    }
    if (host === 'players.brightcove.net') return source;
  } catch {
    return '';
  }
  return '';
};

const resolveEmbeddedThumbnail = (video: any) => {
  const explicit = String(video?.thumbnail || video?.poster || '').trim();
  if (explicit) return explicit;
  const source = resolveEmbeddedVideoLink(video);
  try {
    const parsed = new URL(source);
    const host = parsed.hostname.replace(/^www\./, '').toLowerCase();
    if (host === 'vimeo.com' || host.endsWith('.vimeo.com')) {
      const id = video?.vimeoId || parsed.pathname.match(/\/(?:video\/)?(\d+)/)?.[1];
      return id ? `https://vumbnail.com/${id}.jpg` : '';
    }
    if (host === 'youtu.be' || host === 'youtube.com' || host.endsWith('.youtube.com')) {
      const id =
        parsed.searchParams.get('v') ||
        parsed.pathname.match(/\/(?:embed|shorts|live)\/([^/?#]+)/)?.[1] ||
        (host === 'youtu.be' ? parsed.pathname.split('/').filter(Boolean)[0] : '');
      return id ? `https://i.ytimg.com/vi/${id}/hqdefault.jpg` : '';
    }
  } catch {
    return '';
  }
  return '';
};

const providerAllowsLocalEmbed = (video: any) => {
  const source = resolveEmbeddedVideoLink(video);
  try {
    const host = new URL(source).hostname.replace(/^www\./, '').toLowerCase();
    // YouTube embeds frequently render "Watch video on YouTube / Error 153"
    // inside localhost/package contexts, which looks like a broken player card.
    // Keep the card actions, but show the thumbnail instead of a live iframe.
    if (host.includes('youtube.com') || host === 'youtu.be') return false;
    return host.includes('wistia.com') || host.includes('wistia.net');
  } catch {
    return false;
  }
};

const videoTitleBase = (video: any, idx: number) => {
  const metadataTitle = String(video?.title || video?.name || video?.label || '').trim();
  if (metadataTitle && !/^(?:file|video)(?:\.[a-z0-9]+)?$/i.test(metadataTitle)) return metadataTitle;

  const filename = String(video?.url || '').split('/').pop()?.split('?')[0] || '';
  if (filename && !/^(?:file|video)(?:\.[a-z0-9]+)?$/i.test(filename)) return filename;

  const provider = String(video?.provider || video?.platform || '').trim();
  return `${provider ? `${provider} ` : ''}Video ${idx + 1}`;
};

const videoCardTitle = (video: any, idx: number, videos: any[]) => {
  const base = videoTitleBase(video, idx);
  const duplicatePosition = videos
    .slice(0, idx + 1)
    .filter((candidate, candidateIdx) => videoTitleBase(candidate, candidateIdx).toLowerCase() === base.toLowerCase())
    .length;
  const duplicateCount = videos.filter(
    (candidate, candidateIdx) => videoTitleBase(candidate, candidateIdx).toLowerCase() === base.toLowerCase()
  ).length;
  if (duplicateCount <= 1) return base;

  const quality = String(video?.resolution || video?.formatNote || '').trim();
  const sameQualityCount = videos.filter(
    (candidate, candidateIdx) =>
      videoTitleBase(candidate, candidateIdx).toLowerCase() === base.toLowerCase() &&
      String(candidate?.resolution || candidate?.formatNote || '').trim().toLowerCase() === quality.toLowerCase()
  ).length;
  if (quality && sameQualityCount === 1) return `${base} ${quality}`;
  return `${base} ${duplicatePosition}`;
};

const DEFAULT_VIDEO_URLS = [
  { label: 'Instagram', url: 'https://www.instagram.com/reel/DZK34RqhrSr/' },
  { label: 'Facebook', url: 'https://www.facebook.com/facebook/videos/grandpas-have-the-best-life-hacks-tbh-video-by-life-with-wes-alison-comedy-sketc/454290807152360/' },
  { label: 'X.com', url: 'https://x.com/LetsXOtt/status/1991751366520500536' },
];

export default function VideoExtractor({
  videos,
  seedUrl = '',
  hideManualSearch = false,
  onDownloadReady,
  onOpenInDownloader,
}: {
  videos: any[];
  seedUrl?: string;
  hideManualSearch?: boolean;
  onDownloadReady?: (notice: { title: string; detail?: string; target: string; sourcePageUrl?: string; folderPath?: string }) => void;
  onOpenInDownloader?: (request: { url: string; sourcePageUrl?: string; saveToWebsiteAssets?: boolean }) => void;
}) {
  const [downloadResult, setDownloadResult] = useState<{ url: string; message: string; error?: boolean } | null>(null);
  const [copiedEmbeddedLink, setCopiedEmbeddedLink] = useState<string | null>(null);
  const [manualUrl, setManualUrl] = useState(seedUrl || DEFAULT_VIDEO_URLS[0].url);
  const [activeManualUrl, setActiveManualUrl] = useState('');
  const [brightcovePreviews, setBrightcovePreviews] = useState<Record<string, { thumbnail?: string; title?: string }>>({});
  const visibleVideos = dedupeVisibleVideoCards(
    videos
      .filter((video) => isUsableExtractedVideo(video, seedUrl))
      .map((video) => normalizeExtractedVideoCard(video, seedUrl))
      .filter((video) => !isTechnicalVideoItem(video) && isUsableExtractedVideo(video, seedUrl)),
    seedUrl
  );
  const missingBrightcovePreviewKey = visibleVideos
    .filter((video) => canonicalBrightcovePlayerUrlFromItem(video, seedUrl) && !String(video?.thumbnail || video?.poster || '').trim())
    .map((video) => canonicalBrightcovePlayerUrlFromItem(video, seedUrl))
    .filter(Boolean)
    .sort()
    .join('|');

  useEffect(() => {
    if (!missingBrightcovePreviewKey) return;
    const controller = new AbortController();
    const urls = missingBrightcovePreviewKey.split('|').filter(Boolean);
    void Promise.all(
      urls.map(async (url) => {
        try {
          const response = await fetch(`/api/video-preview?url=${encodeURIComponent(url)}`, { signal: controller.signal });
          const payload = await response.json();
          return [url, payload?.preview || {}] as const;
        } catch {
          return [url, {}] as const;
        }
      })
    ).then((entries) => {
      if (controller.signal.aborted) return;
      setBrightcovePreviews((current) => ({ ...current, ...Object.fromEntries(entries) }));
    });
    return () => controller.abort();
  }, [missingBrightcovePreviewKey]);

  const displayVideos = visibleVideos.map((video) => {
    const url = canonicalBrightcovePlayerUrlFromItem(video, seedUrl);
    const preview = url ? brightcovePreviews[url] : null;
    if (!preview?.thumbnail && !preview?.title) return video;
    return {
      ...video,
      thumbnail: video?.thumbnail || video?.poster || preview.thumbnail || '',
      title: /^Brightcove video(?:\s+\d+)?$/i.test(String(video?.title || ''))
        ? preview.title || video.title
        : video.title,
    };
  });

  useEffect(() => {
    if (!seedUrl && manualUrl && !activeManualUrl) {
      setActiveManualUrl(manualUrl);
    }
  }, []);

  const handleDownload = (video: any) => {
    const cardUrl = String(video?.url || '');
    const request = resolveVideoDownloadRequest(video, seedUrl);
    if (!request.url) {
      setDownloadResult({ url: cardUrl, message: 'No downloadable video link was found.', error: true });
      return;
    }
    setDownloadResult(null);
    onOpenInDownloader?.({
      url: request.url,
      sourcePageUrl: seedUrl || request.sourcePageUrl,
      saveToWebsiteAssets: true,
    });
  };

  const handleManualSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (manualUrl.trim()) {
      setActiveManualUrl(manualUrl.trim());
    }
  };

  const handleCopyEmbeddedLink = async (link: string) => {
    try {
      const bridge = getDesktopBridge();
      if (bridge) {
        const copied = await bridge.writeClipboardText(link);
        if (copied !== link) throw new Error('Desktop clipboard verification failed');
      } else {
        const response = await fetch('/api/clipboard/write', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text: link }),
        });
        if (!response.ok) throw new Error('System clipboard write failed');
      }
      setCopiedEmbeddedLink(link);
      window.setTimeout(() => setCopiedEmbeddedLink((current) => (current === link ? null : current)), 2000);
    } catch {
      const textarea = document.createElement('textarea');
      textarea.value = link;
      textarea.style.position = 'fixed';
      textarea.style.opacity = '0';
      document.body.appendChild(textarea);
      textarea.select();
      const copied = document.execCommand('copy');
      document.body.removeChild(textarea);
      if (!copied) return;
      setCopiedEmbeddedLink(link);
      window.setTimeout(() => setCopiedEmbeddedLink((current) => (current === link ? null : current)), 2000);
    }
  };

  const renderExternalOptions = (url: string) => (
    <div className="grid grid-cols-1 gap-4">
      <a
        href={`https://www.viddown.net/?url=${encodeURIComponent(url)}`}
        target="_blank"
        rel="noopener noreferrer"
        className="flex flex-col items-center justify-center p-4 border border-zinc-200 rounded-xl bg-white hover:bg-zinc-50 transition-colors shadow-sm"
        title="Open in Viddown"
      >
        <span className="font-semibold text-zinc-900 mb-1">Viddown</span>
        <span className="text-xs text-zinc-500 text-center">Video Downloader</span>
      </a>
    </div>
  );

  return (
    <div className="space-y-8">
      {/* Manual Video Downloader Section */}
      {!hideManualSearch ? <div className="bg-white border border-zinc-200 rounded-2xl p-6 shadow-sm">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 bg-indigo-50 rounded-full flex items-center justify-center">
            <Search className="w-5 h-5 text-indigo-600" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-zinc-900">Search & Download Any Video</h3>
            <p className="text-sm text-zinc-500">Paste a link from YouTube, Vimeo, Twitter, Facebook, Instagram, and more</p>
          </div>
        </div>

        <form onSubmit={handleManualSearch} className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Globe className="w-5 h-5 text-zinc-400" />
            </div>
            <label htmlFor="video-url-input" className="sr-only">Video URL</label>
            <input
              id="video-url-input"
              type="url"
              value={manualUrl}
              onChange={(e) => setManualUrl(e.target.value)}
              placeholder="https://www.youtube.com/watch?v=..."
              className="block w-full pl-10 pr-3 py-3 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm bg-zinc-50"
              required
            />
          </div>
          <button
            type="submit"
            className="bg-indigo-600 text-white px-6 py-3 rounded-xl font-medium hover:bg-indigo-700 transition-colors flex items-center justify-center gap-2"
          >
            <Search className="w-4 h-4" />
            Search
          </button>
        </form>
        <div className="mt-3 flex flex-wrap gap-2">
          {DEFAULT_VIDEO_URLS.map((item) => (
            <button
              key={item.label}
              type="button"
              onClick={() => {
                setManualUrl(item.url);
                setActiveManualUrl(item.url);
              }}
              className={`rounded-full px-3 py-1 text-xs font-medium transition-colors ${
                activeManualUrl === item.url
                  ? 'bg-indigo-100 text-indigo-700'
                  : 'bg-zinc-100 text-zinc-600 hover:bg-zinc-200'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        {activeManualUrl && (
          <div className="mt-6 bg-zinc-50 p-6 border border-zinc-100 rounded-xl animate-in fade-in slide-in-from-top-4 duration-300">
            <h4 className="text-sm font-medium text-zinc-700 mb-4 flex items-center gap-2">
              <Download className="w-4 h-4" />
              Download Options for {(() => {
                try { return new URL(activeManualUrl).hostname.replace('www.', ''); }
                catch { return 'this link'; }
              })()}
            </h4>

            {renderExternalOptions(activeManualUrl)}
          </div>
        )}
      </div> : null}

      {displayVideos.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 text-zinc-500 bg-white border border-zinc-200 rounded-2xl border-dashed">
          <VideoIcon className="w-12 h-12 mb-4 text-zinc-300" />
          <p className="text-lg font-medium text-zinc-900">No videos extracted from page</p>
          <p className="text-sm text-center max-w-md mt-1">We couldn't detect any direct video links on the extracted page. Use the search bar above to download videos manually.</p>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {displayVideos.map((video, idx) => {
            const isYouTubeDirect = video.isYouTubeDirect;
            const displayTitle = isYouTubeDirect
              ? `YouTube Video Stream (${video.resolution || 'Unknown'})`
              : videoCardTitle(video, idx, displayVideos);
            const embedded = isEmbeddedVideo(video);
            const embeddedLink = resolveEmbeddedVideoLink(video);
            const embedPreviewUrl = embedded ? resolveEmbedPreviewUrl(video) : '';
            const embeddedThumbnail = embedded ? resolveEmbeddedThumbnail(video) : '';
            const showLiveEmbed = Boolean(embedPreviewUrl && providerAllowsLocalEmbed(video));
            const isDirectCdnVideo = Boolean(
              video?.isDirect ||
              video?.isVimeoDirect ||
              video?.isWistiaDirect ||
              video?.isYouTubeDirect ||
              isDirectVideoAssetUrl(String(video?.url || ''))
            );
            const copyUrl = isDirectCdnVideo ? String(video?.url || '') : (embeddedLink || String(video?.url || ''));

            return (
              <div
                key={idx}
                data-testid="video-card"
                data-video-title={displayTitle}
                data-video-embedded={embedded ? 'true' : 'false'}
                className="bg-white border border-zinc-200 rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-shadow flex flex-col"
              >
                <div className="aspect-video bg-zinc-900 relative group">
                  {showLiveEmbed ? (
                    <iframe
                      src={embedPreviewUrl}
                      title={displayTitle}
                      className="w-full h-full border-0"
                      allow="autoplay; fullscreen; picture-in-picture"
                      allowFullScreen
                      loading="lazy"
                    />
                  ) : embedded ? (
                    <div className="relative flex h-full w-full items-center justify-center overflow-hidden">
                      {embeddedThumbnail ? (
                        <img
                          src={embeddedThumbnail}
                          alt={`${displayTitle} embedded video preview`}
                          className="h-full w-full object-cover"
                          loading="lazy"
                        />
                      ) : (
                        <VideoIcon className="h-10 w-10 text-zinc-600" aria-hidden="true" />
                      )}
                    </div>
                  ) : (
                    <video
                      src={video.url}
                      controls
                      className="w-full h-full object-contain"
                      preload="metadata"
                    />
                  )}
                </div>
                <div className="p-5 flex-1 flex flex-col justify-between">
                  <div className="mb-4">
                    <h3 className="font-semibold text-zinc-900 truncate" title={displayTitle}>
                      {displayTitle}
                    </h3>
                    <div className="flex items-center gap-2 mt-2 flex-wrap">
                      <span className="text-xs bg-zinc-100 text-zinc-600 px-2 py-1 rounded-md uppercase tracking-wider font-medium">
                        {video.type}
                      </span>
                      {embedded ? (
                        <span className="text-xs bg-amber-50 text-amber-700 px-2 py-1 rounded-md font-medium">
                          Embedded player
                        </span>
                      ) : null}
                      {video.resolution && video.resolution !== 'audio only' && video.resolution !== 'Unknown' && (
                        <span className="text-xs bg-indigo-50 text-indigo-600 px-2 py-1 rounded-md font-medium">
                          {video.resolution}
                        </span>
                      )}
                      {video.fps && (
                        <span className="text-xs bg-blue-50 text-blue-600 px-2 py-1 rounded-md font-medium">
                          {video.fps}fps
                        </span>
                      )}
                      {video.formatNote && (
                        <span className="text-xs bg-emerald-50 text-emerald-600 px-2 py-1 rounded-md font-medium">
                          {video.formatNote}
                        </span>
                      )}
                      {video.filesize && (
                        <span className="text-xs bg-orange-50 text-orange-600 px-2 py-1 rounded-md font-medium">
                          {(video.filesize / 1024 / 1024).toFixed(1)} MB
                        </span>
                      )}
                      {video.vcodec && video.vcodec !== 'none' && (
                        <span className="text-xs bg-purple-50 text-purple-600 px-2 py-1 rounded-md font-medium truncate max-w-[100px]" title={video.vcodec}>
                          {video.vcodec}
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="space-y-2">
                    {!isDirectCdnVideo ? (
                      <button
                        type="button"
                        onClick={() => handleDownload(video)}
                        className="flex w-full items-center justify-center gap-2 rounded-xl bg-blue-600 px-4 py-2.5 text-sm font-medium text-white transition-colors hover:bg-blue-700"
                      >
                        <Download className="w-4 h-4" />
                        Download Video
                      </button>
                    ) : null}
                    <button
                      type="button"
                      onClick={() => void handleCopyEmbeddedLink(copyUrl)}
                      className="flex w-full items-center justify-center gap-2 rounded-xl border border-zinc-300 bg-white px-4 py-2.5 text-sm font-medium text-zinc-900 transition-colors hover:bg-zinc-50"
                      title="Copy video URL"
                      aria-label="Copy video URL"
                    >
                      {copiedEmbeddedLink === copyUrl ? (
                        <>
                          <Check className="h-4 w-4 text-emerald-600" />
                          Copied
                        </>
                      ) : (
                        <>
                          <Copy className="h-4 w-4" />
                          Copy URL
                        </>
                      )}
                    </button>
                  </div>
                  {downloadResult?.url === video.url ? (
                    <p className={`mt-2 text-xs font-medium ${downloadResult.error ? 'text-red-600' : 'text-emerald-700'}`}>
                      {downloadResult.message}
                    </p>
                  ) : null}
                </div>
              </div>
            );
            })}
          </div>
        </>
      )}
    </div>
  );
}
