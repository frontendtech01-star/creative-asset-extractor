#!/bin/zsh
set -e
cd "${0:A:h}"

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js is required. Install the current LTS version from https://nodejs.org/"
  read "?Press Return to close..."
  exit 1
fi

echo "Closing older Creative Asset Extractor server sessions..."
pkill -f 'node .*scripts/dev\.mjs' 2>/dev/null || true
pkill -f 'tsx.*server\.ts' 2>/dev/null || true
pkill -f 'node .*scripts/start-localhost\.mjs' 2>/dev/null || true

echo "Cleaning old caches and temporary files..."
rm -rf node_modules package-lock.json .vite .cache
rm -rf "$HOME/.cache/puppeteer"
rm -rf "$HOME/Library/Caches/puppeteer"
rm -rf "$HOME/Library/Caches/Creative Asset Extractor"
find "${TMPDIR:-/tmp}" -maxdepth 1 -type d -name 'creative-asset-extractor-*' -exec rm -rf {} + 2>/dev/null || true
npm cache clean --force >/dev/null 2>&1 || true

echo "Installing a clean runtime without bundled Chromium..."
PUPPETEER_SKIP_DOWNLOAD=true npm install

echo "Starting Creative Asset Extractor on localhost..."
PUPPETEER_SKIP_DOWNLOAD=true npm run localhost
